<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "geo";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$lat = $_POST['lat'];
$lng = $_POST['lng'];

$sql = "INSERT INTO locations (latitude, longitude) VALUES ('$lat', '$lng')";

if ($conn->query($sql) === TRUE) {
    echo "Location saved successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>