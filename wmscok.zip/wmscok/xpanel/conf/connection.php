<?php
    $koneksi =mysqli_connect('localhost','root','','wms');
    
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $sql = "INSERT INTO locations (latitude, longitude) VALUES ('$lat', '$lng')";


    $device_name = $_POST['device_name'];
    $device_type = $_POST['device_type'];
    $status = $_POST['status'];

    // Query untuk menyimpan data
    $sql = "INSERT INTO devices (device_name, device_type, status) VALUES ('$device_name', '$device_type', '$status')";
   
   
    /*  if(!$koneksi){
        die("Koneksi gagal: " .mysqli_connect_error());
    }
    else{
        echo "Koneksi Berhasil";
    }
*/

?>